// JavaScript Document
var Fbutton
var Fbutton = document.querySelector(".Social:nth-of-type(1) button");

Fbutton.addEventListener("onclick", Verander);

function Verander(){
    Fbutton.classList.add("Social");
}